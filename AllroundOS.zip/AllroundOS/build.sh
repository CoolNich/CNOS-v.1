#!/usr/bin/env bash
# Builds the AllroundOS ISO (run as root on Debian/Ubuntu with live-build installed)
set -euo pipefail
cd "$(dirname "$0")"
chmod +x config/hooks/live/*.hook.chroot config/includes.chroot/usr/local/bin/* || true
lb clean || true
lb config \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --binary-images iso-hybrid \
  --debian-installer none \
  --bootappend-live "boot=live components quiet splash" \
  --iso-application "AllroundOS" \
  --iso-volume "AllroundOS"
lb build
mv -f live-image-amd64.hybrid.iso AllroundOS-amd64.iso
echo "Done: AllroundOS-amd64.iso"
